<?php
namespace app\index\controller;
use think\controller\Rest;

class Index extends Rest
{
    public function index()
    {

        $test = input("a");
        if($test){
            echo "1";
        }
        else{
            echo "2";
        }
    	
    }
}
