<?php

namespace app\admin\controller;

class Admin
{
	public function index()
	{
		return $this->fetch();
	}
}
	



